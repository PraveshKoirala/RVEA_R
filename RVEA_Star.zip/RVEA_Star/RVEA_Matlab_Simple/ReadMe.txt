%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  The source code of the reference vector guided evolutionary algorithm (RVEA)
%%
%%  See the details of RVEA in the following paper
%%
%%  R. Cheng, Y. Jin, M. Olhofer and B. Sendhoff, 
%%  A Reference Vector Guided Evolutionary Algorithm for Many-objective Optimization,
%%  IEEE Transactions on Evolutionary Computation, 2016
%%
%%  The source code of RVEA is implemented by Ran Cheng 
%%
%%  If you have any questions about the code, please contact: 
%%  Ran Cheng at ranchengcn@gmail.com
%%  Prof. Yaochu Jin at yaochu.jin@surrey.ac.uk
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
%% To use the programme, please simply run RVEA_Main.m
%%
%% Function List:
%% RVEA_Main.m:	the main file of the programme
%% F_select.m: APD based selection
%% F_weight.m: function to generate uniform weight vectors
%% P_objective.m: definition of Objective function
%% P_generator.m: code for genetic crossover and mutation
%% P_output.m: output the results