%RVEA Main File
format compact;tic;

%basic settings
Problem = 'ExampleProblem';
M = 3; % number of objectives
Generations = 1000; % number of generations

% H1, H2 contains the parameter for the two-layer simplex lattice design up
% to 15 objectives, you may also add new settings by yourself
% The number of reference vectors (i.e., population size N) to be generated is determined by h1, h2 and M
H1 = [49 13  7  5  4  3  3  3  3  2  2  2  2  2]; h1 = H1(M-1);
H2 = [ 0  0  0  0  1  2  2  2  2  2  2  2  2  2]; h2 = H2(M-1);
N = nchoosek(h1+M-1,M-1) + nchoosek(h2+M-1,M-1); % the number of reference vectors

Evaluations = Generations*N; % max number of fitness evaluations
alpha = 2.0; % the parameter in APD, the bigger, the faster RVEA converges
fr = 0.1; % frequency to call reference vector

%reference vector initialization
[N,Vs] = F_weight(h1,h2,M);
for i = 1:N
    Vs(i,:) = Vs(i,:)./norm(Vs(i,:));
end;
V = Vs;
Generations = floor(Evaluations/N);


%calculat neighboring angle for angle normalization
cosineVV = V*V';
[scosineVV, neighbor] = sort(cosineVV, 2, 'descend');
acosVV = acos(scosineVV(:,2));
refV = (acosVV);

%population initialization
rand('seed', sum(100 * clock));
%function 'P_objective' defines the problems to be optimized, please refer to file 'P_objective.m'
[Population,Boundary] = P_objective('init',Problem,M,N);
FunctionValue = P_objective('value',Problem,M,Population);

for Gene = 0 : Generations - 1
    %reproduction to generate offspring population
    Offspring = P_generator(Population,Boundary,N);  %crossover and mutation
    Population = [Population; Offspring]; % merge parent population with children population
    FunctionValue = [FunctionValue; P_objective('value',Problem,M,Offspring);]; % fitness evaluation
    
    %APD based selection
    theta0 =  (Gene/(Generations))^alpha*(M);
    [Selection] = F_select(FunctionValue,V, theta0, refV);
    Population = Population(Selection,:);
    FunctionValue = FunctionValue(Selection,:);

    %reference vector adaption
    if(mod(Gene, ceil(Generations*fr)) == 0)
        %update the reference vectors
        Zmin = min(FunctionValue,[],1);	
        Zmax = max(FunctionValue,[],1);	
        V = Vs;
        V = V.*repmat((Zmax - Zmin)*1.0,N,1);
        for i = 1:N
            V(i,:) = V(i,:)./norm(V(i,:));
        end;
        %update the neighborning angle value for angle normalization
        cosineVV = V*V';
        [scosineVV, neighbor] = sort(cosineVV, 2, 'descend');
        acosVV = acos(scosineVV(:,2));
        refV = (acosVV); 
    end;

    clc; fprintf('Progress %4s%%\n',num2str(round(Gene/Generations*100,-1)));

end;
P_output(Population,toc,'RVEA',Problem,M);


