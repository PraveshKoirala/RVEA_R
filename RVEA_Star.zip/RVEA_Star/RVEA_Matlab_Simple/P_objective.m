%You can implement your own optimization problem, refer to function 'P_ExampleProblem'

function [Output,Boundary] = P_objective(Operation,Problem,M,Input)

% Operation - 'init': to initialze a population, and the population size is
%                     specified with 'Input', and the population is returned as
%                     'Output'; in addition, the boundary of the decision
%                     variables are returned with 'Boundary'
%
%           - 'value': to evaluate the fitness values of a population, and
%                      the fitness vector are returned by 'Output'; in this
%                      case, the 'Boundary' is empty
%
% M - number of objectives
% Problem - optimization problem
% Input - refer to the illustrations on 'Operation'
% 

k = find(~isstrprop(Problem,'digit'),1,'last');
    switch Problem(1:k)
        case 'ExampleProblem'
            [Output,Boundary] = P_ExampleProblem(Operation,M,Input);
        case 'DTLZ'
            [Output,Boundary] = P_DTLZ(Operation,Problem,M,Input);
        case 'SDTLZ'
            [Output,Boundary] = P_SDTLZ(Operation,Problem,M,Input);
        otherwise
            error([Problem,'Not Exist']);
    end
end

function [Output,Boundary] = P_ExampleProblem(Operation,M,Input)
switch Operation
    %Population Initialization
    case 'init'
        
        D = 10; %number of decision variables
        MaxValue   = ones(1,D); %upper boundary of decision variables
        MinValue   = zeros(1,D); %lower boundary of decision variables
        Population = rand(Input,D);
        Population = Population.*repmat(MaxValue,Input,1)+(1-Population).*repmat(MinValue,Input,1);
        
        Output   = Population;
        Boundary = [MaxValue;MinValue];
        %Objective Function Evaluation
    case 'value'
        Population    = Input;
        FunctionValue = zeros(size(Population,1),M);
        g = sum((Population(:,M:end)-0.5).^2,2);
        for i = 1 : M
            FunctionValue(:,i) = (1+g).*prod(cos(0.5.*pi.*Population(:,1:M-i)),2);
            if i > 1
                FunctionValue(:,i) = FunctionValue(:,i).*sin(0.5.*pi.*Population(:,M-i+1));
            end
        end
        Output = FunctionValue;
        Boundary = []; % Not available for fitness evaluation
end
end

